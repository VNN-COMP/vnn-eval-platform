# VNN-COMP benchmark skeleton

Minimal skeleton for a VNN-COMP benchmark proposal. `generate_properties.py`
has the seed argument parsed and `TODO`s where your instance-generation logic
goes.

Running it must produce, at the repository root:

- `onnx/` — generated `.onnx` network files
- `vnnlib/` — generated `.vnnlib` specification files
- `instances.csv` — one row per instance: `<onnx_path>,<vnnlib_path>,<timeout>`

Optional:

- `install.sh` — runs at the repository root during clone/setup, before
  generation, e.g. to install the dependencies your generator needs.

Submit the directory containing `generate_properties.py` as the scripts
directory. See the benchmark info page for the full pipeline.
