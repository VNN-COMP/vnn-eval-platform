#!/bin/bash

# install.sh (optional) — runs at the repository root during clone/setup,
# before generate_properties.py. Use it to install the dependencies your
# generator needs.

# TODO: install your generator dependencies here.
