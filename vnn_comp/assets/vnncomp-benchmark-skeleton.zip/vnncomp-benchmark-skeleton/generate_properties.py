#!/usr/bin/env python3
"""generate_properties.py -- VNN-COMP benchmark generator skeleton.

Called as:

    python3 generate_properties.py <seed>

Running it must produce, at the repository root:
  - onnx/          directory with the generated .onnx network files
  - vnnlib/        directory with the generated .vnnlib specification files
  - instances.csv  one row per instance: <onnx_path>,<vnnlib_path>,<timeout>

Everything marked TODO is benchmark-specific and up to you.
"""
import csv
import os
import random
import sys

ONNX_DIR = "onnx"
VNNLIB_DIR = "vnnlib"
INSTANCES_CSV = "instances.csv"


def main() -> None:
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <seed>")
        sys.exit(1)

    seed = int(sys.argv[1])
    random.seed(seed)

    os.makedirs(ONNX_DIR, exist_ok=True)
    os.makedirs(VNNLIB_DIR, exist_ok=True)

    instances = []

    # TODO: generate your benchmark instances here. For each instance:
    #   1. write the network to onnx/<name>.onnx
    #   2. write the specification to vnnlib/<name>.vnnlib
    #   3. append (onnx_path, vnnlib_path, timeout_in_seconds) to `instances`
    #
    # Example:
    #   instances.append((f"{ONNX_DIR}/example.onnx",
    #                     f"{VNNLIB_DIR}/example.vnnlib", 60))

    with open(INSTANCES_CSV, "w", newline="") as f:
        writer = csv.writer(f)
        for onnx_path, vnnlib_path, timeout in instances:
            writer.writerow([onnx_path, vnnlib_path, timeout])


if __name__ == "__main__":
    main()
