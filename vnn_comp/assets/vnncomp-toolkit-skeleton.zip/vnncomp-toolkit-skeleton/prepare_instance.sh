#!/bin/bash

# prepare_instance.sh — run before each benchmark instance.
# Arguments:
# - $1: version string, e.g. "v1"
# - $2: benchmark identifier, e.g. "acasxu"
# - $3: path to the .onnx file
# - $4: path to the .vnnlib file
#
# A nonzero exit code skips this benchmark category.

VERSION_STRING="v1"

# check arguments
if [ "$1" != "$VERSION_STRING" ]; then
    echo "Expected first argument (version string) '$VERSION_STRING', got '$1'"
    exit 1
fi

BENCHMARK=$2
ONNX_FILE=$3
VNNLIB_FILE=$4

echo "Preparing benchmark instance '$BENCHMARK' with onnx file '$ONNX_FILE' and vnnlib file '$VNNLIB_FILE'"

# TODO: prepare any instance-specific data your toolkit needs
#       (e.g. convert/compile the network, warm up caches, ...).

exit 0
