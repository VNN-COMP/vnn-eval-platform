#!/bin/bash

# post_install.sh (optional) — runs on the instance after installation.
#
# This script is NOT executed from the repository. Paste its contents into the
# "Post installation script" field on the submission form. It is the place for
# steps that depend on the created machine, such as license activation or final
# environment adjustments.

# TODO: add your post-installation steps here.
