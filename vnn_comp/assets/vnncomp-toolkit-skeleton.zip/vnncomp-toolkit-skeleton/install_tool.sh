#!/bin/bash

# install_tool.sh — run once on the AWS instance to install your toolkit.
# Argument:
# - $1: version string, e.g. "v1"

VERSION_STRING="v1"

# check arguments
if [ "$1" != "$VERSION_STRING" ]; then
    echo "Expected first argument (version string) '$VERSION_STRING', got '$1'"
    exit 1
fi

# TODO: install your toolkit here (dependencies, environments, build steps, ...).
