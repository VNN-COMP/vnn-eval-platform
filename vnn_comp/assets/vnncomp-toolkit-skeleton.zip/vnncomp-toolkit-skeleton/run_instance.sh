#!/bin/bash

# run_instance.sh — run your toolkit on a single benchmark instance.
# Arguments:
# - $1: version string, e.g. "v1"
# - $2: benchmark identifier, e.g. "acasxu"
# - $3: path to the .onnx file
# - $4: path to the .vnnlib file
# - $5: path to the results .csv file to write
# - $6: timeout in seconds

VERSION_STRING="v1"

# check arguments
if [ "$1" != "$VERSION_STRING" ]; then
    echo "Expected first argument (version string) '$VERSION_STRING', got '$1'"
    exit 1
fi

BENCHMARK=$2
ONNX_FILE=$3
VNNLIB_FILE=$4
RESULTS_FILE=$5
TIMEOUT=$6

echo "Running on benchmark instance '$BENCHMARK' with onnx file '$ONNX_FILE', vnnlib file '$VNNLIB_FILE', results file '$RESULTS_FILE', and timeout '$TIMEOUT'"

# TODO: run your verifier and write the result to "$RESULTS_FILE".
#       The result is one of: unsat, sat, unknown, timeout, error.
#       For a "sat" result, also write the counterexample in the format required
#       by the VNN-COMP rules (see the toolkit info page for VNNLIB 1.0 / 2.0
#       counterexample examples).
