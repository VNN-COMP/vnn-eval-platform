# VNN-COMP toolkit skeleton

Minimal skeleton for a VNN-COMP toolkit submission. Each script has argument
parsing already in place and `TODO`s where your tool-specific logic goes.

Required scripts:

- `install_tool.sh` — run once to install the toolkit.
- `prepare_instance.sh` — run before each benchmark instance.
- `run_instance.sh` — run the toolkit on a single instance and write the result.

Optional:

- `post_install.sh` — a template for the post-installation step. It is not run
  from the repository; paste its contents into the "Post installation script"
  field on the submission form.

Submit the directory containing the required scripts as the scripts directory.
See the toolkit info page for the full submission pipeline and the counterexample
format.
